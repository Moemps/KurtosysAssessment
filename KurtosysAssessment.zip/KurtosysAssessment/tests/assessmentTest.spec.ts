import { test, expect } from '@playwright/test';

test('Error message on Empty required field', async ({ page }) => {
  await page.goto('https://www.kurtosys.com/');

  await page.locator('//div[@class="kurtosys-menu-title"]//span[contains(text(),"Resources")]').hover()

  /** Resources menu displays */
  await expect(page.locator('//ul/li[3]//div[@class="kurtosys-sub-mega-menu"]')).toBeVisible()
  await page.locator('(//*/a[@href="https://www.kurtosys.com/white-papers/"])[1]').click()

  /** Verify title of page */

  await expect(page.locator('//h2')).toHaveText("White Papers")

  /** Wait for page to fully load */
  await page.waitForLoadState("networkidle")

/** Select UCITS Whitepaper tile */
await page.locator('//article[5]//p[@class="elementor-post__title"]').click()
await page.waitForLoadState("networkidle")


/** Fill fields  */
const firstName = page.frameLocator(`//iframe[@type='text/html']`).getByLabel('First Name');
await firstName.fill('Xavier')

const lastName = page.frameLocator(`//iframe[@type='text/html']`).getByLabel('Last Name');
await lastName.fill('Thomas')

const company = page.frameLocator(`//iframe[@type='text/html']`).getByLabel('Company');
await company.fill('Kurtosys')

const industry = page.frameLocator(`//iframe[@type='text/html']`).getByLabel('Industry');
await industry.fill('IT')

await page.pause()
const submit = page.frameLocator(`//iframe[@type='text/html']`).getByPlaceholder("submit")
await submit.click()

const requiredError = await page.frameLocator(`//iframe[@type='text/html']`).getByText("This field is required.")
await requiredError.screenshot({path: 'error.png'})
});

